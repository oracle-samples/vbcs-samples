define([], function() {
  'use strict';
  return function() {};
});

//# sourceMappingURL=start-page.js.map