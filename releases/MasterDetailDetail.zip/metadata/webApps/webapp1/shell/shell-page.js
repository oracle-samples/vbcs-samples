define([], function() {
  'use strict';

  var ShellModule = function ShellModule() {};

  return ShellModule;
});
