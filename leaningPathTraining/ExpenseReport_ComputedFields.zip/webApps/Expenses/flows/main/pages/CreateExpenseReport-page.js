define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.endDateAfterStartDateValidator = function(startDate) {
    return [{
      validate: (endDate) => {
        if (endDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('Doing it wrong!!!');
          }
          return valid;
        }
      },
    }];
  };

  return PageModule;
});
