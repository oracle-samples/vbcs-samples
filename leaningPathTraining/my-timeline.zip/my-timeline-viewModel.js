/**
  Copyright (c) 2015, 2019, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/

'use strict';

define(
  [
    'knockout',
    'jquery',
    'ojL10n!./resources/nls/my-timeline-strings',
    'ojs/ojknockout',
    'ojs/ojtimeline',
    'ojs/ojselectcombobox',
    'ojs/ojlabel',
    'ojs/ojformlayout'
  ],
  function (ko, $, componentStrings, seriesData) {
    function ExampleComponentModel(context) {
      var self = this;

      // At the start of your viewModel constructor
      var busyContext = oj.Context.getContext(context.element).getBusyContext();
      var options = {
        "description": "Web Component Startup - Waiting for data"
      };
      self.busyResolve = busyContext.addBusyState(options);
      self.composite = context.element;

      self.properties = context.properties;
      self.res = componentStrings['my-timeline'];


      self.items = ko.observableArray();
      self.emptyTextMessage = ko.observable('Loading data...');
      self.itemSelection = ko.observableArray([]);
      var currentDate = new Date('April, 1 2019');

      self.startYearValue = ko.observable((currentDate.getFullYear() - 1));
      self.endYearValue = ko.observable(currentDate.getFullYear() + 1);
      self.yearList = ko.observableArray([]);

      // watch for a change in the startYearValue from the pulldown
      // and adjust the startDate of the timeline as needed.
      self.startDate = ko.pureComputed(function () {
        return new Date(String(self.startYearValue())).toISOString();
      });
      // same watch for endDate changes.
      self.endDate = ko.pureComputed(function () {
        return new Date(String(self.endYearValue())).toISOString();
      });

      // setting the aria-label string with dynamic content.
      self.dynamicLabel = ko.observable('ERP Invoices timeline for years between ' +
        self.startYearValue() + ' and ' + self.endYearValue());

      // Using a computed observable to update the timeline date and emptyText message
      // when data changes.
      self.timelineSeries = ko.pureComputed(function () {
        return [{
          id: 's1',
          emptyText: self.emptyTextMessage(),
          label: 'ERP Invoices',
          items: self.items()
        }];
      });

      // Generate the list of 100 years that can be used for the timeline range changes.
      self._generateYears();
    } // End Constructor

    // Used for initialization of the data.
    ExampleComponentModel.prototype.bindingsApplied = function (context) {
      var self = this;
      self._extractArrayFromDataProvider(self.properties.items, self._shapeTimelineData, 10)
        .then(function (transformedArray) {
          self.items(transformedArray);
          self.busyResolve();
        });
    };

    // Used to handle the use case where the dataProvider passed into the component changes at runtime.
    ExampleComponentModel.prototype.propertyChanged = function (context) {
      var self = this;
      if (context.property === 'items' && context.updatedFrom ===
        'external') {
        self._extractArrayFromDataProvider(context.value, self._shapeTimelineData, 10)
          .then(function (transformedArray) {
            self.items(transformedArray);
          });
      }
    };

    // Extracting the array of date from the passed in DataProvider.
    // This is done so the REST service data can be mapped to the structure
    // that the timeline expects for it's data.
    ExampleComponentModel.prototype._extractArrayFromDataProvider =
      function (dataProvider, rowTransformer, rowLimit) {
        var self = this;
        return new Promise(function (resolve) {
          var limit = rowLimit ? rowLimit : 20;
          if (dataProvider) {
            var options = {
              size: limit
            };

            // If a transformation callback function was provided, return true.
            var doTransform = (typeof rowTransformer ===
              'function');

            // return the data from the DataProvider
            var dpIterator = dataProvider.fetchFirst(options)[Symbol.asyncIterator]();

            // iterate through the data and build the array of data for the timeline.
            dpIterator.next().then(function (result) {
              var extractedArray = [];
              if (result.value.data && result.value.data.length > 0) {
                result.value.data.forEach(function (row, index, allArray) {
                  extractedArray.push(doTransform ? rowTransformer(row) : row);
                });
              }
              self.emptyTextMessage('No data available');
              resolve(extractedArray);
            });
          } else {
            resolve([]);
          }
        });
      };

    // mapping the data from the REST service into a format that the timeline expects.
    // Also setting special styles and thumbnail images based on specific values in the data.
    ExampleComponentModel.prototype._shapeTimelineData = function (sourceRow) {
      // change the border style and thumbnail color based on type of status type
      var status = {
        Requested: {
          color: 'green',
          img: require.toUrl('my-timeline/resources/images/box_01.png')
        },
        Denied: {
          color: 'red',
          img: require.toUrl('my-timeline/resources/images/box_02.png')
        }
      };

      // Alternate option, changes the style and thumbnail based on transaction source.
      var transactionSourceDetails = {
        Manual: {
          color: 'green',
          img: require.toUrl('my-timeline/resources/images/box_01.png')
        },
        Electronic: {
          color: 'red',
          img: require.toUrl('my-timeline/resources/images/box_02.png')
        }
      };
      return {
        id: sourceRow.id,
        title: sourceRow.BusinessUnit,
        start: sourceRow.TransactionDate,
        description: "$" + sourceRow.totalAmount,
        thumbnail: status[sourceRow.status].img,
        svgStyle: 'border-color:' +
          status[sourceRow.status].color +
          ';'
      };
    };

    // Creating an array of years for use in the timeline range pulldowns
    ExampleComponentModel.prototype._generateYears = function (context) {
      var self = this;
      var tempArray = [];
      for (var year = 1950; year < 2050; year++) {
        tempArray.push({
          value: year,
          label: year
        });
      }
      self.yearList(tempArray);
    };

    return ExampleComponentModel;
  }
);
