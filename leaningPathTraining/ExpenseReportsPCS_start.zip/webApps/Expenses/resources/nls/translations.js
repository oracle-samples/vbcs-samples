define(function() {
  'use strict';

  return {
    root: {}
  };
});
