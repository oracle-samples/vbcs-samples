define([], function() {
  'use strict';

  var PageModule = function PageModule() {};  
  
  PageModule.prototype.endDateAfterStartDateValidator = function(startDate) {
    return [{
      validate: (endDate) => {
        if (endDate) {
          const valid = endDate >= startDate;
          if (!valid) {
            throw new Error('End date must be start date or later');
          }
          return valid;
        }
      },
    }];
  };
 

  return PageModule;
});
