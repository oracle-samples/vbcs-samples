# Local Events Application

A simple app demonstrating Push Notification events